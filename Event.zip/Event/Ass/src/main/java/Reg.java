/*import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Reg")
public class Reg extends HttpServlet  {
			@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		String e=req.getParameter("t5");
		String f=req.getParameter("t6");
		String g=req.getParameter("t7");
		String but=req.getParameter("b1");
		
		
		
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		
			 PreparedStatement ps=con.prepareStatement("insert into Reg values(?,?,?,?,?,?,?)");
			ps.setInt(1,Integer.parseInt(a));
			ps.setString(2,b);
			ps.setInt(3,Integer.parseInt(c));
			ps.setString(4,d);
			ps.setInt(5,Integer.parseInt(e));
			ps.setString(6,f);
			ps.setInt(7,Integer.parseInt(g));
			ps.execute();
			res.sendRequest("index.html");
		
		
		
		}
		
		
		catch(Exception ae)
		{
			ae.printStackTrace();
		}		}}	*/		









/*import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Reg")
public class Reg extends HttpServlet {
			@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		String e=req.getParameter("t5");
		String f=req.getParameter("t6");
		String g=req.getParameter("t7");
		String but=req.getParameter("b1");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("insert into Reg values(?,?,?,?,?,?,?)");
		 ps.setString(1,a);
			ps.setString(2,b);
			ps.setString(3,c);
			ps.setString(4,d);
			ps.setString(5,e);
			ps.setString(6,f);
			ps.setString(7,g);
			ps.execute();
			res.sendRedirect("index.html");
		   
	}	
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		}}*/





import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Reg")
public class Reg extends HttpServlet {
			@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		String e=req.getParameter("t5");
		
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("insert into Reg values(?,?,?,?,?)");
			ps.setString(1,a);
			ps.setString(2,b);
			ps.setString(3,c);
			ps.setString(4,d);
			ps.setString(5,e);
			
			ps.execute();
			res.sendRedirect("index.html");
		
	}	
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		}}



