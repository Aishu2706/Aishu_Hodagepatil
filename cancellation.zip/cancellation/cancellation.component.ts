import { Component, OnInit } from '@angular/core';


declare var name: any;



@Component({
  selector: 'app-cancellation',
  templateUrl: './cancellation.component.html',
  styleUrls: ['./cancellation.component.css']
})
export class CancellationComponent implements OnInit {

   

  ngOnInit(): void {
    new name();
  }

}
